const KEYS = {
  COMPLETED_DAYS: "slwm_completed_days",
  START_DATE: "slwm_start_date",
  CHAT_HISTORY: "slwm_chat_history",
};

export function getCompletedDays() {
  try { return JSON.parse(localStorage.getItem(KEYS.COMPLETED_DAYS)) || []; }
  catch { return []; }
}

export function markDayComplete(day) {
  const completed = getCompletedDays();
  if (!completed.includes(day)) {
    completed.push(day);
    localStorage.setItem(KEYS.COMPLETED_DAYS, JSON.stringify(completed));
  }
}

export function isDayComplete(day) { return getCompletedDays().includes(day); }
export function getTotalCompleted() { return getCompletedDays().length; }

export function getCurrentStreak() {
  const completed = getCompletedDays().sort((a, b) => a - b);
  if (completed.length === 0) return 0;
  let streak = 0;
  const last = completed[completed.length - 1];
  for (let d = last; d >= 1; d--) {
    if (completed.includes(d)) streak++;
    else break;
  }
  return streak;
}

export function initStartDate() {
  if (!localStorage.getItem(KEYS.START_DATE))
    localStorage.setItem(KEYS.START_DATE, new Date().toISOString());
}

export function getChatHistory() {
  try { return JSON.parse(localStorage.getItem(KEYS.CHAT_HISTORY)) || []; }
  catch { return []; }
}

export function addChatMessage(role, content) {
  const history = getChatHistory();
  history.push({ role, content, timestamp: Date.now() });
  localStorage.setItem(KEYS.CHAT_HISTORY, JSON.stringify(history.slice(-50)));
}
