import { missions, colorTokens } from "../data/missions";
import { getCompletedDays, getTotalCompleted } from "../utils/storage";
import ProgressTracker from "../components/ProgressTracker";

function MissionCard({ mission, completed, active, locked, onClick }) {
  const t = colorTokens[mission.color] || colorTokens.peach;
  const style = completed ? { background: t.card, border: `2px solid ${t.accent}` }
    : active ? { background: "white", border: `2px solid ${t.accent}`, boxShadow: `0 0 0 3px ${t.badge}` }
    : { background: "#f9f9f9", border: "2px solid #eee", opacity: 0.55 };

  return (
    <button onClick={() => !locked && onClick(mission.day)} disabled={locked}
      className="relative rounded-2xl p-4 text-left transition-all duration-200 w-full focus:outline-none focus:ring-2 focus:ring-orange-300 hover:scale-[1.02] active:scale-[0.98] disabled:cursor-not-allowed disabled:hover:scale-100"
      style={style}>
      <div className="flex items-start justify-between mb-2">
        <span className="text-xs font-black tracking-wide px-2 py-0.5 rounded-full" style={{ background: t.badge, color: t.text }}>
          DAY {mission.day}
        </span>
        <span className="text-xl">{completed ? "✅" : active ? mission.emoji : "🔒"}</span>
      </div>
      <p className={`font-black text-sm leading-tight ${locked ? "text-gray-300" : "text-gray-700"}`}>{mission.title}</p>
      {!locked && <p className="text-xs text-gray-400 mt-1 font-medium">{mission.duration}</p>}
      {active && (
        <div className="absolute -top-1.5 -right-1.5 text-xs font-black px-2 py-0.5 rounded-full animate-pulse" style={{ background: "#FFD3B6", color: "#c07040" }}>
          TODAY ✨
        </div>
      )}
    </button>
  );
}

export default function MissionsPage({ onDaySelect, onBack }) {
  const completedDays = getCompletedDays();
  const totalDone     = getTotalCompleted();
  const nextDay       = totalDone + 1;

  return (
    <div className="min-h-screen pb-20" style={{ background: "radial-gradient(ellipse at top,#E8F8F0 0%,#FFF9F5 60%)", fontFamily: '"Nunito", sans-serif' }}>
      {/* Top bar */}
      <div className="sticky top-0 z-20 px-5 py-4 border-b border-orange-50 backdrop-blur-sm" style={{ background: "rgba(255,249,245,0.9)" }}>
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-xl hover:bg-orange-50 transition-colors text-orange-400 font-bold">← Back</button>
          <div className="flex-1">
            <h1 className="text-xl font-black text-gray-800">Your 30-Day Journey 🗓️</h1>
            <p className="text-xs text-gray-400">
              {totalDone === 0 ? "Day 1 is waiting for you!" : `${totalDone}/30 days complete — you're crushing it!`}
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-5 pt-5 space-y-6">
        <ProgressTracker onDayClick={onDaySelect}/>

        {/* Day 0 welcome card */}
        <div className="rounded-2xl p-5 border-2 cursor-pointer hover:scale-[1.01] transition-transform"
          style={{ background: "#f3f0ff", borderColor: "#c3a9d9" }}
          onClick={() => onDaySelect(0)} role="button" tabIndex={0}
          onKeyDown={e => e.key === "Enter" && onDaySelect(0)}>
          <div className="flex items-center gap-3">
            <span className="text-3xl">🌱</span>
            <div>
              <p className="font-black text-purple-800 text-base">Day 0 — Welcome to the Reset</p>
              <p className="text-purple-500 text-xs mt-0.5">Read this before you begin</p>
            </div>
          </div>
        </div>

        {/* Mission grid */}
        <div>
          <h2 className="font-black text-gray-700 text-base mb-3">The 30 Missions 🎯</h2>
          <div className="grid grid-cols-2 gap-3">
            {missions.map(mission => {
              const completed = completedDays.includes(mission.day);
              const active    = mission.day === nextDay;
              const locked    = mission.day > nextDay && !completed;
              return <MissionCard key={mission.day} mission={mission} completed={completed} active={active} locked={locked} onClick={onDaySelect}/>;
            })}
          </div>
        </div>

        <div className="rounded-2xl p-5 text-center" style={{ background: "linear-gradient(135deg,#FFD3B6 0%,#FFE8D6 100%)" }}>
          <p className="text-orange-700 font-bold text-sm">
            💡 Tip: Miss a day? No problem! Just pick up where you left off.<br/>
            <span className="font-normal opacity-80">Progress &gt; perfection, always.</span>
          </p>
        </div>
      </div>
    </div>
  );
}
