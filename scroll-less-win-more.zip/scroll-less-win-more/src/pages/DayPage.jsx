import { useState } from "react";
import { missions, colorTokens } from "../data/missions";
import DetoxBuddy, { BuddyAvatar } from "../components/DetoxBuddy";
import { isDayComplete, markDayComplete } from "../utils/storage";

const DAY_ZERO = {
  day: 0, title: "Welcome to the Reset", emoji: "🌱", duration: "5 min read", color: "lavender",
  vibe: "A gentle, judgement-free rebellion against your own phone.",
  mission: "Tonight's only job: Put your phone charger outside your bedroom. Just for tonight. That's it. That's Day 0.",
  scrollSwap: "You don't need to do anything tonight except read this page and breathe. The challenge starts gently.",
  winTip: "You found this. That means some part of you already knows the phone isn't giving you what you actually need. You're not broken. You're just a human in 2026 whose brain has been gently hijacked by an algorithm designed by people who study behavioural psychology for a living. The playing field was never fair.",
  offlineWin: "Over the next 30 days you'll swap some scrolling for things that actually feel good, rebuild your attention span, and feel more like yourself again.",
};

function Section({ icon, label, content, colorName }) {
  const t = colorTokens[colorName] || colorTokens.peach;
  return (
    <div className="rounded-2xl p-5 border" style={{ background: t.bg, borderColor: t.card }}>
      <div className="flex items-center gap-2 mb-2">
        <span className="text-lg">{icon}</span>
        <span className="text-xs font-black tracking-wide uppercase px-2 py-0.5 rounded-full" style={{ background: t.badge, color: t.text }}>
          {label}
        </span>
      </div>
      <p className="text-gray-700 text-sm leading-relaxed">{content}</p>
    </div>
  );
}

export default function DayPage({ day, onBack, onComplete }) {
  const missionData     = day === 0 ? DAY_ZERO : missions.find(m => m.day === day);
  const [complete, setComplete]         = useState(() => day > 0 && isDayComplete(day));
  const [showBuddy, setShowBuddy]       = useState(false);
  const [justCompleted, setJustCompleted] = useState(false);

  if (!missionData) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ fontFamily: '"Nunito", sans-serif' }}>
        <div className="text-center">
          <p className="text-gray-400 text-lg mb-4">Day not found 🤔</p>
          <button onClick={onBack} className="text-orange-400 font-bold">← Go back</button>
        </div>
      </div>
    );
  }

  const t = colorTokens[missionData.color] || colorTokens.peach;

  function handleComplete() {
    if (day === 0 || complete) return;
    markDayComplete(day);
    setComplete(true);
    setJustCompleted(true);
    onComplete?.(day);
    setTimeout(() => setShowBuddy(true), 600);
  }

  return (
    <div className="min-h-screen pb-24" style={{ background: `radial-gradient(ellipse at top,${t.bg} 0%,#FFF9F5 70%)`, fontFamily: '"Nunito", sans-serif' }}>
      {/* Top bar */}
      <div className="sticky top-0 z-10 px-5 py-4 border-b backdrop-blur-sm flex items-center gap-3"
        style={{ background: "rgba(255,249,245,0.93)", borderColor: t.card }}>
        <button onClick={onBack} className="p-2 rounded-xl hover:bg-orange-50 transition-colors font-bold" style={{ color: t.accent }}>
          ← Back
        </button>
        <div className="flex-1">
          <p className="text-xs font-black tracking-widest uppercase" style={{ color: t.accent }}>
            {day === 0 ? "Welcome" : `Day ${day} of 30`}
          </p>
          <h1 className="text-base font-black text-gray-800 leading-tight">{missionData.title}</h1>
        </div>
        <span className="text-2xl">{missionData.emoji}</span>
      </div>

      <div className="max-w-xl mx-auto px-5 pt-6 space-y-4">
        {/* Hero card */}
        <div className="rounded-3xl p-6 text-center shadow-sm border"
          style={{ background: `linear-gradient(135deg,${t.card} 0%,${t.bg} 100%)`, borderColor: t.badge }}>
          <div className="text-5xl mb-3">{missionData.emoji}</div>
          <h2 className="text-2xl font-black" style={{ color: t.text }}>{missionData.title}</h2>
          <div className="inline-flex items-center gap-2 mt-2 px-3 py-1 rounded-full text-xs font-bold"
            style={{ background: t.badge, color: t.text }}>
            ⏱ {missionData.duration}
          </div>
          <p className="text-gray-500 text-sm mt-3 italic leading-relaxed">"{missionData.vibe}"</p>
        </div>

        <Section icon="🎯" label="Daily Mission"  content={missionData.mission}    colorName={missionData.color}/>
        <Section icon="📊" label="Scroll Swap"    content={missionData.scrollSwap} colorName={missionData.color}/>
        <Section icon="💡" label="Win Tip"        content={missionData.winTip}     colorName={missionData.color}/>
        <Section icon="🌟" label="Offline Win"    content={missionData.offlineWin} colorName={missionData.color}/>

        {/* Complete button */}
        {day > 0 && (
          <div className="pt-2">
            {complete ? (
              <div className="rounded-2xl p-5 text-center border-2" style={{ background: t.bg, borderColor: t.accent }}>
                <div className="text-3xl mb-2">✅</div>
                <p className="font-black text-green-700 text-base">Day {day} complete!</p>
                {justCompleted && <p className="text-green-500 text-sm mt-1">Amazing! Detox Buddy wants to celebrate 🎉</p>}
              </div>
            ) : (
              <button onClick={handleComplete}
                className="w-full py-4 rounded-2xl font-black text-lg shadow-lg hover:shadow-xl transition-all hover:scale-[1.02] active:scale-[0.98]"
                style={{ background: `linear-gradient(135deg,${t.accent} 0%,${t.badge} 100%)`, color: t.text }}>
                ✅ Mark Day {day} Complete!
              </button>
            )}
          </div>
        )}

        {/* Detox Buddy chat toggle */}
        <div>
          <button onClick={() => setShowBuddy(v => !v)}
            className="w-full flex items-center justify-between px-5 py-4 rounded-2xl border shadow-sm hover:shadow-md transition-all"
            style={{ background: "linear-gradient(135deg,#FFD3B6 0%,#FFE8D6 100%)", borderColor: "#FFD3B6" }}>
            <div className="flex items-center gap-3">
              <BuddyAvatar size={36} animated={false}/>
              <div className="text-left">
                <p className="font-black text-orange-800 text-sm">Chat with Detox Buddy</p>
                <p className="text-orange-500 text-xs">Got a question? Need a cheer? 🌟</p>
              </div>
            </div>
            <span className="text-orange-400">{showBuddy ? "▲" : "▼"}</span>
          </button>
          {showBuddy && <div className="mt-3"><DetoxBuddy currentDay={day}/></div>}
        </div>

        {/* Prev / Next nav */}
        <div className="flex gap-3 pt-2">
          {day > 1 && (
            <button onClick={() => onBack(day - 1)}
              className="flex-1 py-3 rounded-xl border font-bold text-sm text-gray-500 hover:bg-gray-50 transition-colors">
              ← Day {day - 1}
            </button>
          )}
          {day > 0 && day < 30 && complete && (
            <button onClick={() => onBack(day + 1)}
              className="flex-1 py-3 rounded-xl font-bold text-sm text-white shadow hover:shadow-md transition-all"
              style={{ background: t.accent }}>
              Day {day + 1} →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
