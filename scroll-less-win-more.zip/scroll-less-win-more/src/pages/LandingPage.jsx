import { BuddyAvatar } from "../components/DetoxBuddy";
import { getTotalCompleted, initStartDate } from "../utils/storage";

const features = [
  { emoji: "📅", title: "30 Daily Missions", desc: "One easy challenge each day (10–45 min)" },
  { emoji: "🤖", title: "Detox Buddy AI", desc: "Your personal cheerleader, powered by AI" },
  { emoji: "🔥", title: "Streak Tracker", desc: "Build momentum day by day" },
  { emoji: "🎯", title: "No Cold Turkey", desc: "Progress over perfection, always" },
];

const groundRules = [
  { icon: "💚", title: "No perfection required.", desc: "Miss a day? Cool. Pick it back up." },
  { icon: "🤝", title: "No cold turkey.", desc: "This isn't a punishment. It's an upgrade." },
  { icon: "😄", title: "Laugh at yourself.", desc: "If you open Instagram to post about doing a dopamine detox — that's chef's kiss irony." },
];

export default function LandingPage({ onStart }) {
  const daysCompleted = getTotalCompleted();
  const isReturning   = daysCompleted > 0;

  function handleStart() {
    initStartDate();
    onStart();
  }

  return (
    <div className="min-h-screen" style={{ background: "radial-gradient(ellipse at top left,#FFE8D6 0%,#FFF9F5 40%,#E8F8F0 100%)", fontFamily: '"Nunito", sans-serif' }}>
      {/* Hero */}
      <section className="flex flex-col items-center px-6 pt-16 pb-10 text-center max-w-2xl mx-auto">
        <div className="mb-4 relative">
          <div className="absolute inset-0 rounded-full blur-2xl opacity-30 scale-150" style={{ background: "#FFD3B6" }}/>
          <BuddyAvatar size={120} animated/>
        </div>
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold mb-4 tracking-wide" style={{ background: "#FFD3B6", color: "#c07040" }}>
          🌟 30-DAY DOPAMINE RESET CHALLENGE
        </div>
        <h1 className="text-5xl font-black leading-tight mb-3" style={{ background: "linear-gradient(135deg,#e8845a 0%,#c3a9d9 60%,#4db88a 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
          Scroll Less,<br/>Win More!!!
        </h1>
        <p className="text-gray-500 text-lg mb-2 leading-relaxed max-w-lg">
          Hey friend! Welcome to your gentle 30-day reset.
        </p>
        <p className="text-gray-400 text-base mb-8 leading-relaxed max-w-lg">
          No guilt, no cold turkey — just fun daily missions that help you scroll less and feel more energised. One easy mission per day (10–45 mins). Progress &gt; perfection 😊
        </p>
        <button onClick={handleStart}
          className="px-10 py-4 rounded-2xl text-lg font-black shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105 active:scale-95"
          style={{ background: "linear-gradient(135deg,#FFB3BA 0%,#FFD3B6 50%,#FFEAA7 100%)", color: "#7a3030" }}>
          {isReturning ? `Continue (Day ${daysCompleted + 1}) 🚀` : "Start the Challenge 🚀"}
        </button>
        {isReturning && <p className="text-gray-400 text-sm mt-3">Welcome back! You've completed {daysCompleted} day{daysCompleted !== 1 ? "s" : ""} 🎉</p>}
      </section>

      {/* Quote */}
      <section className="px-6 pb-8 max-w-xl mx-auto">
        <div className="rounded-3xl p-6 text-center border" style={{ background: "#fffdf0", borderColor: "#ffeaa7" }}>
          <p className="text-yellow-700 text-base font-semibold italic leading-relaxed">
            "You don't have to quit the internet. You just have to remember that you were interesting before it existed."
          </p>
        </div>
      </section>

      {/* Features */}
      <section className="px-6 pb-10 max-w-2xl mx-auto">
        <h2 className="text-center text-2xl font-black text-gray-700 mb-5">What's inside? 🎁</h2>
        <div className="grid grid-cols-2 gap-4">
          {features.map(f => (
            <div key={f.title} className="rounded-2xl p-5 text-center shadow-sm border border-orange-50 bg-white">
              <div className="text-3xl mb-2">{f.emoji}</div>
              <p className="font-bold text-gray-700 text-sm">{f.title}</p>
              <p className="text-gray-400 text-xs mt-1">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Ground rules */}
      <section className="px-6 py-10" style={{ background: "linear-gradient(135deg,#f3f0ff 0%,#e8f8f0 100%)" }}>
        <div className="max-w-xl mx-auto">
          <h2 className="text-center text-2xl font-black text-gray-700 mb-6">The 3 Ground Rules 📋</h2>
          <div className="space-y-4">
            {groundRules.map(rule => (
              <div key={rule.title} className="flex gap-4 items-start bg-white rounded-2xl p-4 shadow-sm border border-purple-50">
                <span className="text-2xl">{rule.icon}</span>
                <div>
                  <p className="font-bold text-gray-700 text-sm">{rule.title}</p>
                  <p className="text-gray-400 text-xs mt-0.5">{rule.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="px-6 py-10 text-center max-w-xl mx-auto">
        <div className="rounded-3xl p-8 shadow-md" style={{ background: "linear-gradient(135deg,#FFD3B6 0%,#FFE8D6 100%)" }}>
          <BuddyAvatar size={60} animated/>
          <h3 className="text-xl font-black text-orange-800 mt-3 mb-2">Ready to meet your Detox Buddy?</h3>
          <p className="text-orange-600 text-sm mb-5">Buddy is here every day to cheer you on, answer questions, and celebrate your wins. No judgment. Just good vibes.</p>
          <button onClick={handleStart} className="px-8 py-3 rounded-xl font-black text-white shadow hover:shadow-md transition-all hover:scale-105 active:scale-95" style={{ background: "#e8845a" }}>
            Let's do this! 💪
          </button>
        </div>
      </section>
    </div>
  );
}
