import { getCompletedDays, getCurrentStreak, getTotalCompleted } from "../utils/storage";

function getStreakMessage(streak) {
  if (streak === 0) return "Start your streak today! 🌱";
  if (streak === 1) return "Day 1 streak — you've begun! 🌿";
  if (streak < 5)  return `${streak} days in a row — warming up! ✨`;
  if (streak < 10) return `${streak} day streak — now we're talking! 🔥`;
  if (streak < 20) return `${streak} days straight — you're on fire! 🚀`;
  if (streak < 30) return `${streak} day streak — almost there! 🌟`;
  return "30 days! You are an absolute legend! 🏆";
}

export default function ProgressTracker({ onDayClick }) {
  const completedDays = getCompletedDays();
  const streak        = getCurrentStreak();
  const total         = getTotalCompleted();
  const nextDay       = total + 1;
  const pct           = Math.round((total / 30) * 100);

  return (
    <div className="bg-white rounded-3xl shadow-md border border-orange-100 p-5" style={{ fontFamily: '"Nunito", sans-serif' }}>
      {/* Stats */}
      <div className="flex gap-3 mb-4">
        {[
          { val: streak, label: "DAY STREAK 🔥", bg: "linear-gradient(135deg,#FFD3B6 0%,#FFE8D6 100%)", col: "text-orange-600" },
          { val: total,  label: "DAYS DONE ✅",  bg: "linear-gradient(135deg,#c5eddc 0%,#e8f8f0 100%)", col: "text-green-600" },
          { val: 30-total, label: "TO GO 🌟",    bg: "linear-gradient(135deg,#ddd4f5 0%,#f3f0ff 100%)", col: "text-purple-600" },
        ].map(s => (
          <div key={s.label} className="flex-1 rounded-2xl p-3 text-center" style={{ background: s.bg }}>
            <div className={`text-3xl font-black leading-none ${s.col}`}>{s.val}</div>
            <div className="text-xs font-bold text-gray-500 mt-1">{s.label}</div>
          </div>
        ))}
      </div>
      {/* Progress bar */}
      <div className="mb-3">
        <div className="flex justify-between text-xs text-gray-400 mb-1 font-bold">
          <span>Progress</span><span>{pct}%</span>
        </div>
        <div className="w-full bg-orange-50 rounded-full h-3 overflow-hidden">
          <div className="h-3 rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: "linear-gradient(90deg,#FFB3BA 0%,#FFD3B6 50%,#FFEAA7 100%)" }}/>
        </div>
      </div>
      <p className="text-center text-sm font-bold text-orange-500 mb-4">{getStreakMessage(streak)}</p>
      {/* Calendar dots */}
      <div className="grid grid-cols-10 gap-1.5">
        {Array.from({ length: 30 }, (_, i) => i + 1).map(day => (
          <button key={day} onClick={() => onDayClick?.(day)}
            className="focus:outline-none focus:ring-2 focus:ring-orange-300 rounded-full"
            title={`Day ${day}${completedDays.includes(day) ? " ✓" : ""}`}>
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
              completedDays.includes(day) ? "bg-orange-400 text-white scale-105 shadow-sm"
              : day === nextDay ? "bg-orange-100 border-2 border-orange-400 text-orange-600 animate-pulse"
              : "bg-gray-100 text-gray-400"}`}>
              {completedDays.includes(day) ? "✓" : day}
            </div>
          </button>
        ))}
      </div>
      {nextDay <= 30 && <p className="text-center text-xs text-gray-400 mt-3">Day {nextDay} is waiting → tap to open</p>}
    </div>
  );
}
