import { useState, useRef, useEffect } from "react";
import { getChatHistory, addChatMessage } from "../utils/storage";

const GROK_API_KEY = import.meta.env.VITE_GROK_API_KEY || "";
const GROK_MODEL   = "grok-3-fast";

const SYSTEM_PROMPT = `You are Detox Buddy — a warm, funny, encouraging companion for the "Scroll Less, Win More" 30-day dopamine reset challenge. Your personality: gentle, playful, non-judgmental, brief (2-4 sentences max), light humour, occasional emoji. Zero shame. Celebrate small wins. Australian-friendly tone.`;

export function BuddyAvatar({ size = 80, animated = true }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg"
      className={animated ? "animate-float" : ""} aria-label="Detox Buddy">
      <ellipse cx="50" cy="95" rx="22" ry="5" fill="#f0c0a0" opacity="0.4"/>
      <circle cx="50" cy="52" r="38" fill="#FFD3B6"/>
      <circle cx="38" cy="42" r="12" fill="#FFE8D6" opacity="0.6"/>
      <ellipse cx="22" cy="62" rx="9" ry="6" fill="#FFB3BA" opacity="0.6"/>
      <ellipse cx="78" cy="62" rx="9" ry="6" fill="#FFB3BA" opacity="0.6"/>
      <circle cx="38" cy="52" r="9" fill="white"/>
      <circle cx="62" cy="52" r="9" fill="white"/>
      <circle cx="40" cy="53" r="5" fill="#5c3d2e"/>
      <circle cx="64" cy="53" r="5" fill="#5c3d2e"/>
      <circle cx="42" cy="51" r="2" fill="white"/>
      <circle cx="66" cy="51" r="2" fill="white"/>
      <path d="M38 66 Q50 76 62 66" stroke="#c07050" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
      <circle cx="12" cy="36" r="8" fill="#FFD3B6"/>
      <circle cx="12" cy="36" r="5" fill="#FFE8D6"/>
      <circle cx="88" cy="36" r="8" fill="#FFD3B6"/>
      <circle cx="88" cy="36" r="5" fill="#FFE8D6"/>
      <circle cx="50" cy="12" r="4" fill="#FFEAA7"/>
      <line x1="50" y1="16" x2="50" y2="24" stroke="#FFD3B6" strokeWidth="2"/>
    </svg>
  );
}

export default function DetoxBuddy({ currentDay = 1 }) {
  const [messages, setMessages] = useState(() => {
    const h = getChatHistory();
    if (h.length === 0) return [{ role: "assistant", content: `Hey! 👋 I'm Detox Buddy! How's Day ${currentDay} going?` }];
    return h.map(m => ({ role: m.role, content: m.content }));
  });
  const [input, setInput]     = useState("");
  const [loading, setLoading] = useState(false);
  const [voiceOn, setVoiceOn] = useState(false);
  const endRef                = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  async function sendMessage() {
    const trimmed = input.trim();
    if (!trimmed || loading) return;
    const userMsg = { role: "user", content: trimmed };
    setMessages(prev => [...prev, userMsg]);
    addChatMessage("user", trimmed);
    setInput("");
    setLoading(true);
    try {
      if (!GROK_API_KEY) throw new Error("Add VITE_GROK_API_KEY to your .env file to enable chat!");
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${GROK_API_KEY}` },
        body: JSON.stringify({
          model: GROK_MODEL,
          messages: [
            { role: "system", content: SYSTEM_PROMPT + ` Context: User is on Day ${currentDay} of 30.` },
            ...messages.slice(-8),
            userMsg,
          ],
          max_tokens: 250,
          temperature: 0.8,
        }),
      });
      if (!res.ok) throw new Error(`API error ${res.status}`);
      const data = await res.json();
      const reply = data.choices?.[0]?.message?.content || "...";
      setMessages(prev => [...prev, { role: "assistant", content: reply }]);
      addChatMessage("assistant", reply);
      if (voiceOn) speakText(reply);
    } catch (err) {
      setMessages(prev => [...prev, { role: "assistant", content: `Oops! ${err.message}` }]);
    } finally {
      setLoading(false);
    }
  }

  function speakText(text) {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 0.95; u.pitch = 1.1;
    window.speechSynthesis.speak(u);
  }

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  }

  return (
    <div className="flex flex-col bg-white rounded-3xl shadow-lg border border-orange-100 overflow-hidden" style={{ fontFamily: '"Nunito", sans-serif' }}>
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-orange-50" style={{ background: "linear-gradient(135deg,#FFD3B6 0%,#FFE8D6 100%)" }}>
        <BuddyAvatar size={44} animated />
        <div className="flex-1">
          <p className="font-bold text-orange-800 text-sm">Detox Buddy</p>
          <p className="text-orange-500 text-xs">Your challenge companion 🌟</p>
        </div>
        <button onClick={() => setVoiceOn(v => !v)} title={voiceOn ? "Voice on" : "Voice off"}
          className={`p-2 rounded-full transition-colors text-lg ${voiceOn ? "bg-orange-200 text-orange-700" : "bg-white/60 text-orange-300"}`}>
          {voiceOn ? "🔊" : "🔇"}
        </button>
      </div>
      {/* Messages */}
      <div className="overflow-y-auto p-4 space-y-3" style={{ maxHeight: "320px", minHeight: "180px" }}>
        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-2 items-start ${msg.role === "user" ? "flex-row-reverse" : ""}`}>
            {msg.role === "assistant" && <div className="flex-shrink-0 mt-1"><BuddyAvatar size={26} animated={false}/></div>}
            <div className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm leading-relaxed ${msg.role === "user" ? "bg-orange-400 text-white rounded-tr-sm" : "bg-orange-50 text-orange-900 rounded-tl-sm border border-orange-100"}`}>
              {msg.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-2 items-center">
            <BuddyAvatar size={26} animated={false}/>
            <div className="bg-orange-50 border border-orange-100 px-4 py-2 rounded-2xl rounded-tl-sm flex gap-1">
              {[0,150,300].map(d => <span key={d} className="w-2 h-2 bg-orange-300 rounded-full animate-bounce" style={{ animationDelay: `${d}ms` }}/>)}
            </div>
          </div>
        )}
        <div ref={endRef}/>
      </div>
      {/* Input */}
      <div className="p-3 border-t border-orange-50 bg-orange-50/30">
        {!GROK_API_KEY && (
          <p className="text-orange-400 text-xs text-center mb-2 bg-orange-50 rounded-lg px-3 py-1">
            💡 Add <code>VITE_GROK_API_KEY</code> to <code>.env</code> to enable chat
          </p>
        )}
        <div className="flex gap-2">
          <input type="text" value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKeyDown}
            placeholder="Ask Detox Buddy anything…" disabled={loading}
            className="flex-1 bg-white border border-orange-200 rounded-xl px-4 py-2 text-sm text-orange-900 placeholder-orange-300 focus:outline-none focus:ring-2 focus:ring-orange-300 disabled:opacity-50"/>
          <button onClick={sendMessage} disabled={loading || !input.trim()}
            className="bg-orange-400 hover:bg-orange-500 disabled:opacity-40 text-white rounded-xl px-4 py-2 text-sm font-bold transition-colors">
            {loading ? "…" : "Send"}
          </button>
        </div>
      </div>
    </div>
  );
}
